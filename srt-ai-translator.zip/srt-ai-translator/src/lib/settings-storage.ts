import type { LocalApiConfig } from "@/types/database";

const STORAGE_KEY = "srt_ai_translator_local_config_v1";

export const DEFAULT_LOCAL_CONFIG: LocalApiConfig = {
  provider: "openrouter",
  apiKey: "",
  baseUrl: "https://openrouter.ai/api/v1",
  model: "google/gemini-2.5-flash",
  safetyOff: true,
  batchSize: 40,
};

export function loadLocalApiConfig(): LocalApiConfig {
  if (typeof window === "undefined") return DEFAULT_LOCAL_CONFIG;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_LOCAL_CONFIG;
    return { ...DEFAULT_LOCAL_CONFIG, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_LOCAL_CONFIG;
  }
}

export function saveLocalApiConfig(config: LocalApiConfig): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // ignore storage quota errors
  }
}
