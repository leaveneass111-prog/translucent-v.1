import type { GlossaryEntry, LlmProvider, TonePreset } from "@/types/database";

export interface CueInput {
  index: number;
  text: string;
}

export interface ContextCue {
  index: number;
  source: string;
  translated?: string | null;
}

export interface TranslateBatchPayload {
  provider: LlmProvider;
  apiKey: string;
  baseUrl?: string;
  model: string;
  safetyOff?: boolean;
  sourceLang: string;
  targetLang: string;
  tone: TonePreset;
  toneNotes?: string | null;
  synopsis?: string | null;
  glossaryEntries?: GlossaryEntry[];
  contextBefore?: ContextCue[];
  cues: CueInput[];
}

export interface TranslatedCueOutput {
  index: number;
  translated: string;
}
