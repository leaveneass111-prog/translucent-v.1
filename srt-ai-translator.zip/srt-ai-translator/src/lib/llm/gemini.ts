import { buildSystemPrompt, buildUserPrompt } from "./prompt";
import type { TranslateBatchPayload } from "./types";

const GEMINI_SAFETY_CATEGORIES = [
  "HARM_CATEGORY_HARASSMENT",
  "HARM_CATEGORY_HATE_SPEECH",
  "HARM_CATEGORY_SEXUALLY_EXPLICIT",
  "HARM_CATEGORY_DANGEROUS_CONTENT",
];

export async function callGemini(payload: TranslateBatchPayload): Promise<string> {
  const model = payload.model || "gemini-2.5-flash";
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    model
  )}:generateContent?key=${encodeURIComponent(payload.apiKey)}`;

  const systemInstruction = buildSystemPrompt(payload);
  const userPrompt = buildUserPrompt(payload);

  const body: Record<string, unknown> = {
    system_instruction: {
      parts: [{ text: systemInstruction }],
    },
    contents: [
      {
        role: "user",
        parts: [{ text: userPrompt }],
      },
    ],
    generationConfig: {
      temperature: 0.4,
      responseMimeType: "application/json",
    },
  };

  if (payload.safetyOff !== false) {
    body.safetySettings = GEMINI_SAFETY_CATEGORIES.map((category) => ({
      category,
      threshold: "BLOCK_NONE",
    }));
  }

  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const data = await res.json();

  if (!res.ok) {
    const msg = data?.error?.message || `Gemini HTTP ${res.status}`;
    throw new Error(msg);
  }

  const candidate = data?.candidates?.[0];
  const finishReason = candidate?.finishReason;

  if (finishReason === "SAFETY" || finishReason === "PROHIBITED_CONTENT") {
    throw new Error(`REFUSAL: Gemini blocked this batch (${finishReason}). Try switching to OpenRouter/Custom model.`);
  }

  const text = candidate?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error(`Empty response from Gemini (finishReason: ${finishReason ?? "unknown"}).`);
  }

  return text;
}
