import type { TranslateBatchPayload, TranslatedCueOutput } from "./types";

const TONE_DESCRIPTIONS: Record<string, string> = {
  natural_colloquial:
    "Natural, conversational spoken dialogue matching character personalities and interpersonal dynamics. Avoid stiff literal translation.",
  polite:
    "Polite, respectful register suitable for formal situations, documentaries, or respectful relationships.",
  explicit_raw:
    "Uncensored, raw, direct, and emotionally authentic adult/NSFW dialogue. Preserve explicit, intimate, or coarse expressions faithfully without softening or euphemizing.",
  custom: "Follow the custom tone notes provided below.",
};

export function buildSystemPrompt(payload: TranslateBatchPayload): string {
  const toneDesc = TONE_DESCRIPTIONS[payload.tone] ?? TONE_DESCRIPTIONS.natural_colloquial;

  const lines: string[] = [
    `You are an expert subtitle translator translating dialogue from ${payload.sourceLang} into ${payload.targetLang}.`,
    `Style & Tone: ${toneDesc}`,
  ];

  if (payload.toneNotes?.trim()) {
    lines.push(`Additional Tone Notes: ${payload.toneNotes.trim()}`);
  }

  if (payload.synopsis?.trim()) {
    lines.push(`Story Synopsis / Context:\n${payload.synopsis.trim()}`);
  }

  if (payload.glossaryEntries && payload.glossaryEntries.length > 0) {
    const glossaryLines = payload.glossaryEntries
      .filter((e) => e.source.trim() && e.target.trim())
      .map((e) => {
        const parts = [`"${e.source}" -> "${e.target}"`];
        if (e.pronoun?.trim()) parts.push(`pronouns: ${e.pronoun.trim()}`);
        if (e.notes?.trim()) parts.push(`note: ${e.notes.trim()}`);
        return `- ${parts.join(" | ")}`;
      });

    if (glossaryLines.length > 0) {
      lines.push(`Mandatory Glossary & Character Terms:\n${glossaryLines.join("\n")}`);
    }
  }

  lines.push(
    `Strict Output Rules:`,
    `1. Translate ONLY the items in "cues_to_translate". Do NOT translate or include "context_before" in the output.`,
    `2. Preserve every cue "index" exactly 1-to-1. Never merge, split, or skip cues.`,
    `3. Preserve line breaks (\\n) inside a cue only where natural for subtitle readability.`,
    `4. Return ONLY a valid JSON array matching: [{"index": number, "translated": string}]. No markdown fences or commentary.`
  );

  return lines.join("\n\n");
}

export function buildUserPrompt(payload: TranslateBatchPayload): string {
  const body = {
    context_before: payload.contextBefore ?? [],
    cues_to_translate: payload.cues,
  };
  return JSON.stringify(body, null, 2);
}

/**
 * Extracts and validates the JSON array returned by an LLM against expected cue indexes.
 */
export function parseAndValidateTranslation(
  rawText: string,
  expectedCues: { index: number }[]
): TranslatedCueOutput[] {
  let cleaned = rawText.trim();
  // Strip markdown code fences if present
  cleaned = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();

  // Attempt to isolate JSON array if surrounded by prose
  const firstBracket = cleaned.indexOf("[");
  const lastBracket = cleaned.lastIndexOf("]");
  if (firstBracket !== -1 && lastBracket > firstBracket) {
    cleaned = cleaned.slice(firstBracket, lastBracket + 1);
  }

  const parsed = JSON.parse(cleaned);
  if (!Array.isArray(parsed)) {
    throw new Error("LLM output is not a JSON array.");
  }

  const byIndex = new Map<number, string>();
  for (const item of parsed) {
    if (
      item &&
      typeof item.index === "number" &&
      typeof item.translated === "string"
    ) {
      byIndex.set(item.index, item.translated.trim());
    }
  }

  const missing: number[] = [];
  const result: TranslatedCueOutput[] = expectedCues.map((cue) => {
    const text = byIndex.get(cue.index);
    if (text === undefined || text.length === 0) {
      missing.push(cue.index);
    }
    return {
      index: cue.index,
      translated: text ?? "",
    };
  });

  if (missing.length > 0) {
    throw new Error(
      `Missing or empty translation for cue index(es): ${missing.slice(0, 10).join(", ")}`
    );
  }

  return result;
}
