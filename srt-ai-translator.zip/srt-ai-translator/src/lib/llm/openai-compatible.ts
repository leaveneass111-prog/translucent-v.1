import { buildSystemPrompt, buildUserPrompt } from "./prompt";
import type { TranslateBatchPayload } from "./types";

export async function callOpenAiCompatible(
  payload: TranslateBatchPayload
): Promise<string> {
  const defaultBase =
    payload.provider === "openrouter"
      ? "https://openrouter.ai/api/v1"
      : "https://api.openai.com/v1";

  const baseUrl = (payload.baseUrl?.trim() || defaultBase).replace(/\/+$/, "");
  const endpoint = `${baseUrl}/chat/completions`;

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${payload.apiKey}`,
  };

  if (baseUrl.includes("openrouter.ai")) {
    headers["HTTP-Referer"] = "https://srt-ai-translator.vercel.app";
    headers["X-Title"] = "SRT AI Translator";
  }

  const res = await fetch(endpoint, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: payload.model,
      temperature: 0.4,
      messages: [
        { role: "system", content: buildSystemPrompt(payload) },
        { role: "user", content: buildUserPrompt(payload) },
      ],
    }),
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const msg =
      data?.error?.message ||
      data?.message ||
      `Provider HTTP ${res.status}`;
    throw new Error(msg);
  }

  const choice = data?.choices?.[0];
  const content = choice?.message?.content;

  if (!content || typeof content !== "string") {
    throw new Error("Empty response from LLM provider.");
  }

  return content;
}
