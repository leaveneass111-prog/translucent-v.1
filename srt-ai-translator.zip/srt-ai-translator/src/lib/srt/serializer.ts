export interface SerializableCue {
  cue_index: number;
  start_time: string;
  end_time: string;
  source_text: string;
  translated_text: string | null;
}

/**
 * Serializes cues back to valid .srt format, strictly preserving original
 * cue_index and timecodes. Falls back to source_text if translated_text is empty.
 */
export function serializeSrt(cues: SerializableCue[]): string {
  const sorted = [...cues].sort((a, b) => a.cue_index - b.cue_index);

  return (
    sorted
      .map((cue) => {
        const text =
          cue.translated_text && cue.translated_text.trim().length > 0
            ? cue.translated_text.trim()
            : cue.source_text;
        return `${cue.cue_index}\n${cue.start_time} --> ${cue.end_time}\n${text}`;
      })
      .join("\n\n") + "\n"
  );
}

export function buildExportFilename(
  originalFilename: string,
  targetLang: string
): string {
  const base = originalFilename.replace(/\.srt$/i, "");
  const safeLang = targetLang.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "") || "translated";
  return `${base}_${safeLang}.srt`;
}
