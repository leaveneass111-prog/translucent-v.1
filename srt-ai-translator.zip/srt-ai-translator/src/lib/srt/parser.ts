export interface ParsedCue {
  cue_index: number;
  start_time: string;
  end_time: string;
  source_text: string;
}

const TIMECODE_LINE_RE =
  /^(\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})(?:\s+.*)?$/;

function normalizeTimecode(tc: string): string {
  return tc.trim().replace(".", ",");
}

/**
 * Parses a .srt string into structured cues.
 * Handles UTF-8 BOM, CRLF/LF, extra blank lines, and multi-line subtitle text.
 */
export function parseSrt(raw: string): ParsedCue[] {
  const cleaned = raw.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const blocks = cleaned.split(/\n{2,}/);
  const cues: ParsedCue[] = [];

  for (const block of blocks) {
    const lines = block
      .split("\n")
      .map((l) => l.trimEnd())
      .filter((l, idx, arr) => !(idx === arr.length - 1 && l === ""));

    if (lines.length === 0) continue;

    // Find the timecode line (usually line 1, or line 0 if index is missing)
    let tcLineIdx = lines.findIndex((l) => TIMECODE_LINE_RE.test(l.trim()));
    if (tcLineIdx === -1) continue;

    const match = lines[tcLineIdx].trim().match(TIMECODE_LINE_RE);
    if (!match) continue;

    const rawIndex = tcLineIdx > 0 ? parseInt(lines[tcLineIdx - 1].trim(), 10) : NaN;
    const cueIndex = Number.isFinite(rawIndex) ? rawIndex : cues.length + 1;
    const textLines = lines.slice(tcLineIdx + 1);
    const sourceText = textLines.join("\n").trim();

    if (!sourceText) continue;

    cues.push({
      cue_index: cueIndex,
      start_time: normalizeTimecode(match[1]),
      end_time: normalizeTimecode(match[2]),
      source_text: sourceText,
    });
  }

  // Ensure strictly sequential unique cue_index if input had duplicates
  const seen = new Set<number>();
  return cues.map((cue, idx) => {
    let finalIndex = cue.cue_index;
    if (seen.has(finalIndex)) {
      finalIndex = idx + 1;
    }
    seen.add(finalIndex);
    return { ...cue, cue_index: finalIndex };
  });
}
