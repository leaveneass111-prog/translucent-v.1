"use client";

import { useEffect, useState } from "react";
import { Check, KeyRound, Save, ShieldOff } from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";
import {
  DEFAULT_LOCAL_CONFIG,
  loadLocalApiConfig,
  saveLocalApiConfig,
} from "@/lib/settings-storage";
import type { LlmProvider, LocalApiConfig } from "@/types/database";

const PROVIDER_PRESETS: Array<{
  label: string;
  provider: LlmProvider;
  baseUrl: string;
  model: string;
  note: string;
}> = [
  {
    label: "OpenRouter (แนะนำสำหรับเนื้อหาผู้ใหญ่)",
    provider: "openrouter",
    baseUrl: "https://openrouter.ai/api/v1",
    model: "deepseek/deepseek-chat-v3-0324",
    note: "รองรับหลายโมเดลที่ยืดหยุ่น ไม่ติดฟิลเตอร์ง่าย",
  },
  {
    label: "Google Gemini API (AI Studio)",
    provider: "gemini",
    baseUrl: "",
    model: "gemini-2.5-flash",
    note: "เร็ว ประหยัด และเปิดโหมดลดการบล็อก (BLOCK_NONE) ได้",
  },
  {
    label: "xAI Grok (OpenAI-Compatible)",
    provider: "custom",
    baseUrl: "https://api.x.ai/v1",
    model: "grok-3-mini",
    note: "ยืดหยุ่นกับบทสนทนาที่ตรงไปตรงมา",
  },
  {
    label: "DeepSeek Direct",
    provider: "custom",
    baseUrl: "https://api.deepseek.com/v1",
    model: "deepseek-chat",
    note: "แปลภาษาอังกฤษ/ญี่ปุ่นเป็นไทยได้ดีมาก ราคาประหยัด",
  },
];

export default function SettingsPage() {
  const supabase = createClient();
  const [config, setConfig] = useState<LocalApiConfig>(DEFAULT_LOCAL_CONFIG);
  const [defaultSourceLang, setDefaultSourceLang] = useState("en");
  const [defaultTargetLang, setDefaultTargetLang] = useState("th");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setConfig(loadLocalApiConfig());
    (async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from("user_settings")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) {
        setDefaultSourceLang(data.default_source_lang);
        setDefaultTargetLang(data.default_target_lang);
        setConfig((prev) => ({
          ...prev,
          provider: data.default_provider as LlmProvider,
          baseUrl: data.custom_base_url ?? prev.baseUrl,
          model: data.default_model,
          batchSize: data.default_batch_size,
          safetyOff: data.gemini_safety_off,
        }));
      }
    })();
  }, [supabase]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    saveLocalApiConfig(config);

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (user) {
      await supabase.from("user_settings").upsert({
        user_id: user.id,
        default_provider: config.provider,
        custom_base_url: config.baseUrl || null,
        default_model: config.model,
        default_source_lang: defaultSourceLang,
        default_target_lang: defaultTargetLang,
        default_batch_size: config.batchSize,
        gemini_safety_off: config.safetyOff,
      });
    }

    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="min-h-screen bg-[#0d0f14]">
      <NavBar />
      <main className="mx-auto max-w-2xl px-4 py-6 sm:py-8">
        <div className="surface-card rounded-2xl p-5 sm:p-7">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
              <KeyRound className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">ตั้งค่า API & โมเดล (BYOK)</h1>
              <p className="text-xs text-slate-400">
                API Key จะถูกเก็บไว้เฉพาะในเบราว์เซอร์เครื่องนี้ (localStorage) ไม่ถูกบันทึกลงฐานข้อมูล
              </p>
            </div>
          </div>

          <div className="mb-6">
            <p className="mb-2 text-xs font-medium text-slate-300">เลือก Preset ด่วน</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {PROVIDER_PRESETS.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() =>
                    setConfig((prev) => ({
                      ...prev,
                      provider: p.provider,
                      baseUrl: p.baseUrl,
                      model: p.model,
                    }))
                  }
                  className="rounded-xl border border-white/10 bg-[#0d0f14] p-3 text-left transition hover:border-indigo-500/60"
                >
                  <div className="text-xs font-semibold text-white">{p.label}</div>
                  <div className="mt-0.5 text-[11px] text-slate-400">{p.note}</div>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">
                  Provider
                </label>
                <select
                  value={config.provider}
                  onChange={(e) =>
                    setConfig({ ...config, provider: e.target.value as LlmProvider })
                  }
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                >
                  <option value="openrouter">OpenRouter</option>
                  <option value="gemini">Google Gemini API</option>
                  <option value="custom">Custom (OpenAI-Compatible)</option>
                </select>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">
                  Model ID
                </label>
                <input
                  type="text"
                  required
                  value={config.model}
                  onChange={(e) => setConfig({ ...config, model: e.target.value })}
                  placeholder="google/gemini-2.5-flash"
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {config.provider !== "gemini" && (
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">
                  Base URL (OpenAI-Compatible)
                </label>
                <input
                  type="url"
                  value={config.baseUrl}
                  onChange={(e) => setConfig({ ...config, baseUrl: e.target.value })}
                  placeholder="https://openrouter.ai/api/v1"
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>
            )}

            <div>
              <label className="mb-1.5 block text-xs font-medium text-slate-300">
                API Key
              </label>
              <input
                type="password"
                value={config.apiKey}
                onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                placeholder="sk-... หรือ AIza..."
                className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">
                  ภาษาต้นทางเริ่มต้น
                </label>
                <input
                  type="text"
                  value={defaultSourceLang}
                  onChange={(e) => setDefaultSourceLang(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">
                  ภาษาเป้าหมายเริ่มต้น
                </label>
                <input
                  type="text"
                  value={defaultTargetLang}
                  onChange={(e) => setDefaultTargetLang(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">
                  ขนาด Batch (บรรทัด)
                </label>
                <input
                  type="number"
                  min={10}
                  max={100}
                  value={config.batchSize}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      batchSize: Math.min(100, Math.max(10, Number(e.target.value) || 40)),
                    })
                  }
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <label className="flex cursor-pointer items-center justify-between rounded-xl border border-white/10 bg-[#0d0f14] p-3.5">
              <div className="flex items-center gap-2.5">
                <ShieldOff className="h-4 w-4 text-amber-400" />
                <div>
                  <div className="text-xs font-semibold text-white">
                    ลด Safety Filter สำหรับ Gemini (BLOCK_NONE)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    ช่วยลดการบล็อกบทสนทนาสำหรับผู้ใหญ่เมื่อใช้ Gemini API
                  </div>
                </div>
              </div>
              <input
                type="checkbox"
                checked={config.safetyOff}
                onChange={(e) => setConfig({ ...config, safetyOff: e.target.checked })}
                className="h-4 w-4 accent-indigo-500"
              />
            </label>

            <button
              type="submit"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-500"
            >
              {saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
              {saved ? "บันทึกการตั้งค่าแล้ว" : "บันทึกการตั้งค่า"}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
