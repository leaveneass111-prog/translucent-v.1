"use client";

import { useEffect, useState } from "react";
import { Download, Plus, Save, Trash2, Upload } from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";
import type { Glossary, GlossaryEntry, TonePreset } from "@/types/database";

const EMPTY_ENTRY: GlossaryEntry = {
  source: "",
  target: "",
  pronoun: "",
  notes: "",
};

export default function GlossariesPage() {
  const supabase = createClient();
  const [glossaries, setGlossaries] = useState<Glossary[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [tone, setTone] = useState<TonePreset>("natural_colloquial");
  const [toneNotes, setToneNotes] = useState("");
  const [synopsis, setSynopsis] = useState("");
  const [entries, setEntries] = useState<GlossaryEntry[]>([{ ...EMPTY_ENTRY }]);
  const [saving, setSaving] = useState(false);

  async function loadGlossaries() {
    const { data } = await supabase
      .from("glossaries")
      .select("*")
      .order("updated_at", { ascending: false });
    if (data) setGlossaries(data as Glossary[]);
  }

  useEffect(() => {
    loadGlossaries();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function selectGlossary(g: Glossary) {
    setSelectedId(g.id);
    setName(g.name);
    setTone(g.tone);
    setToneNotes(g.tone_notes ?? "");
    setSynopsis(g.synopsis ?? "");
    setEntries(g.entries.length > 0 ? g.entries : [{ ...EMPTY_ENTRY }]);
  }

  function resetNew() {
    setSelectedId(null);
    setName("");
    setTone("natural_colloquial");
    setToneNotes("");
    setSynopsis("");
    setEntries([{ ...EMPTY_ENTRY }]);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const cleanEntries = entries.filter(
        (item) => item.source.trim() || item.target.trim()
      );

      if (selectedId) {
        await supabase
          .from("glossaries")
          .update({
            name: name.trim(),
            tone,
            tone_notes: toneNotes.trim() || null,
            synopsis: synopsis.trim() || null,
            entries: cleanEntries,
          })
          .eq("id", selectedId);
      } else {
        const { data } = await supabase
          .from("glossaries")
          .insert({
            user_id: user.id,
            name: name.trim(),
            tone,
            tone_notes: toneNotes.trim() || null,
            synopsis: synopsis.trim() || null,
            entries: cleanEntries,
          })
          .select()
          .single();
        if (data) setSelectedId(data.id);
      }
      await loadGlossaries();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await supabase.from("glossaries").delete().eq("id", id);
    if (selectedId === id) resetNew();
    await loadGlossaries();
  }

  function handleExportJson() {
    const payload = {
      name: name || "glossary",
      tone,
      tone_notes: toneNotes,
      synopsis,
      entries: entries.filter((e) => e.source.trim() || e.target.trim()),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(name || "glossary").replace(/\s+/g, "_")}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleImportJson(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (parsed.name) setName(String(parsed.name));
        if (parsed.tone) setTone(parsed.tone as TonePreset);
        if (parsed.tone_notes) setToneNotes(String(parsed.tone_notes));
        if (parsed.synopsis) setSynopsis(String(parsed.synopsis));
        if (Array.isArray(parsed.entries) && parsed.entries.length > 0) {
          setEntries(parsed.entries);
        }
      } catch {
        alert("ไฟล์ JSON ไม่ถูกต้อง");
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="min-h-screen bg-[#0d0f14]">
      <NavBar />
      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-3">
        <section className="surface-card rounded-2xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold text-white">ชุด Glossary ของคุณ</h2>
            <button
              onClick={resetNew}
              className="flex items-center gap-1 rounded-lg bg-indigo-600 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-indigo-500"
            >
              <Plus className="h-3.5 w-3.5" /> สร้างใหม่
            </button>
          </div>

          <div className="space-y-2">
            {glossaries.length === 0 && (
              <p className="py-6 text-center text-xs text-slate-500">
                ยังไม่มี Glossary กดสร้างใหม่หรือ Import JSON ได้เลย
              </p>
            )}
            {glossaries.map((g) => (
              <div
                key={g.id}
                className={`flex items-center justify-between rounded-xl border p-3 transition ${
                  selectedId === g.id
                    ? "border-indigo-500 bg-indigo-500/10"
                    : "border-white/10 bg-[#0d0f14] hover:border-white/20"
                }`}
              >
                <button
                  onClick={() => selectGlossary(g)}
                  className="flex-1 text-left"
                >
                  <div className="text-sm font-medium text-white">{g.name}</div>
                  <div className="text-[11px] text-slate-400">
                    {g.entries?.length ?? 0} คำศัพท์ • {g.tone}
                  </div>
                </button>
                <button
                  onClick={() => handleDelete(g.id)}
                  className="ml-2 rounded-lg p-1.5 text-slate-500 hover:bg-rose-500/10 hover:text-rose-400"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="surface-card rounded-2xl p-5 lg:col-span-2">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <h1 className="text-base font-bold text-white">
              {selectedId ? "แก้ไข Glossary" : "สร้าง Glossary ใหม่"}
            </h1>
            <div className="flex items-center gap-2">
              <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-white/10 bg-[#0d0f14] px-3 py-1.5 text-xs text-slate-300 hover:border-white/25">
                <Upload className="h-3.5 w-3.5" /> Import JSON
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleImportJson}
                  className="hidden"
                />
              </label>
              <button
                type="button"
                onClick={handleExportJson}
                className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0d0f14] px-3 py-1.5 text-xs text-slate-300 hover:border-white/25"
              >
                <Download className="h-3.5 w-3.5" /> Export JSON
              </button>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs text-slate-300">ชื่อเรื่อง / ชุด Glossary</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="เช่น ซีรีส์ EP.1-10"
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-slate-300">โทนภาษา (Tone)</label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value as TonePreset)}
                  className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none"
                >
                  <option value="natural_colloquial">ธรรมชาติ / ภาษาพูด (ทั่วไป)</option>
                  <option value="explicit_raw">ดิบ / ตรงไปตรงมา (เนื้อหาผู้ใหญ่)</option>
                  <option value="polite">สุภาพ / เป็นทางการ</option>
                  <option value="custom">กำหนดเอง (ระบุใน Tone Notes)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs text-slate-300">คำอธิบายโทนเพิ่มเติม (ถ้ามี)</label>
              <input
                type="text"
                value={toneNotes}
                onChange={(e) => setToneNotes(e.target.value)}
                placeholder="เช่น ใช้คำหยาบได้ตามอารมณ์ตัวละคร, ห้ามเซ็นเซอร์"
                className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs text-slate-300">เรื่องย่อ / บริบทความสัมพันธ์</label>
              <textarea
                rows={3}
                value={synopsis}
                onChange={(e) => setSynopsis(e.target.value)}
                placeholder="เล่าบริบทเรื่องย่อหรือความสัมพันธ์ตัวละคร เพื่อให้ AI แปลสรรพนามได้แม่นยำ"
                className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between">
                <label className="text-xs font-medium text-slate-300">
                  ตารางคำศัพท์ / ชื่อตัวละคร / สรรพนาม
                </label>
                <button
                  type="button"
                  onClick={() => setEntries([...entries, { ...EMPTY_ENTRY }])}
                  className="text-xs text-indigo-400 hover:text-indigo-300"
                >
                  + เพิ่มแถว
                </button>
              </div>

              <div className="space-y-2">
                {entries.map((entry, idx) => (
                  <div
                    key={idx}
                    className="grid gap-2 rounded-xl border border-white/10 bg-[#0d0f14] p-2.5 sm:grid-cols-12"
                  >
                    <input
                      type="text"
                      placeholder="ต้นฉบับ (เช่น Kenji)"
                      value={entry.source}
                      onChange={(e) => {
                        const next = [...entries];
                        next[idx] = { ...next[idx], source: e.target.value };
                        setEntries(next);
                      }}
                      className="rounded-lg border border-white/10 bg-[#151922] px-2.5 py-1.5 text-xs text-white sm:col-span-3"
                    />
                    <input
                      type="text"
                      placeholder="คำแปล (เช่น เคนจิ)"
                      value={entry.target}
                      onChange={(e) => {
                        const next = [...entries];
                        next[idx] = { ...next[idx], target: e.target.value };
                        setEntries(next);
                      }}
                      className="rounded-lg border border-white/10 bg-[#151922] px-2.5 py-1.5 text-xs text-white sm:col-span-3"
                    />
                    <input
                      type="text"
                      placeholder="สรรพนาม (เช่น ฉัน/นาย)"
                      value={entry.pronoun ?? ""}
                      onChange={(e) => {
                        const next = [...entries];
                        next[idx] = { ...next[idx], pronoun: e.target.value };
                        setEntries(next);
                      }}
                      className="rounded-lg border border-white/10 bg-[#151922] px-2.5 py-1.5 text-xs text-white sm:col-span-2"
                    />
                    <input
                      type="text"
                      placeholder="หมายเหตุ"
                      value={entry.notes ?? ""}
                      onChange={(e) => {
                        const next = [...entries];
                        next[idx] = { ...next[idx], notes: e.target.value };
                        setEntries(next);
                      }}
                      className="rounded-lg border border-white/10 bg-[#151922] px-2.5 py-1.5 text-xs text-white sm:col-span-3"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setEntries(entries.filter((_, i) => i !== idx))
                      }
                      className="flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-400 sm:col-span-1"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white hover:bg-indigo-500 disabled:opacity-50"
            >
              <Save className="h-4 w-4" />
              {saving ? "กำลังบันทึก..." : "บันทึก Glossary"}
            </button>
          </form>
        </section>
      </main>
    </div>
  );
}
