"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  AlertTriangle,
  Download,
  Loader2,
  Pause,
  Play,
  RefreshCw,
  Settings,
} from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";
import { buildExportFilename, serializeSrt } from "@/lib/srt/serializer";
import { loadLocalApiConfig } from "@/lib/settings-storage";
import type {
  Glossary,
  SubtitleCue,
  TranslationProject,
} from "@/types/database";

type FilterMode = "all" | "pending" | "failed" | "done";

export default function ProjectEditorPage() {
  const params = useParams<{ id: string }>();
  const projectId = params.id;
  const supabase = createClient();

  const [project, setProject] = useState<TranslationProject | null>(null);
  const [glossary, setGlossary] = useState<Glossary | null>(null);
  const [cues, setCues] = useState<SubtitleCue[]>([]);
  const [filter, setFilter] = useState<FilterMode>("all");
  const [translating, setTranslating] = useState(false);
  const [activeBatch, setActiveBatch] = useState<number | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const stopRef = useRef(false);
  const saveTimersRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const loadProject = useCallback(async () => {
    const { data: proj } = await supabase
      .from("translation_projects")
      .select("*")
      .eq("id", projectId)
      .single();

    if (proj) {
      const typedProj = proj as TranslationProject;
      setProject(typedProj);
      if (typedProj.glossary_id) {
        const { data: gloss } = await supabase
          .from("glossaries")
          .select("*")
          .eq("id", typedProj.glossary_id)
          .maybeSingle();
        if (gloss) setGlossary(gloss as Glossary);
      }
    }

    // Fetch all cues in pages of 1000
    const allCues: SubtitleCue[] = [];
    let from = 0;
    while (true) {
      const { data: batch } = await supabase
        .from("subtitle_cues")
        .select("*")
        .eq("project_id", projectId)
        .order("cue_index", { ascending: true })
        .range(from, from + 999);
      if (!batch || batch.length === 0) break;
      allCues.push(...(batch as SubtitleCue[]));
      if (batch.length < 1000) break;
      from += 1000;
    }
    setCues(allCues);
    setLoading(false);
  }, [projectId, supabase]);

  useEffect(() => {
    loadProject();
  }, [loadProject]);

  const stats = useMemo(() => {
    const total = cues.length;
    const done = cues.filter(
      (c) => c.status === "translated" || c.status === "edited"
    ).length;
    const failed = cues.filter((c) => c.status === "failed").length;
    const failedBatchNums = Array.from(
      new Set(cues.filter((c) => c.status === "failed").map((c) => c.batch_number))
    ).sort((a, b) => a - b);
    return { total, done, failed, failedBatchNums };
  }, [cues]);

  const filteredCues = useMemo(() => {
    if (filter === "pending") return cues.filter((c) => c.status === "pending");
    if (filter === "failed") return cues.filter((c) => c.status === "failed");
    if (filter === "done")
      return cues.filter((c) => c.status === "translated" || c.status === "edited");
    return cues;
  }, [cues, filter]);

  async function translateSingleBatch(
    batchNum: number,
    currentCues: SubtitleCue[]
  ): Promise<SubtitleCue[]> {
    if (!project) return currentCues;
    const cfg = loadLocalApiConfig();
    if (!cfg.apiKey.trim()) {
      throw new Error("ยังไม่ได้กรอก API Key กรุณาไปที่หน้า 'ตั้งค่า API' ก่อน");
    }

    const batchCues = currentCues.filter((c) => c.batch_number === batchNum);
    if (batchCues.length === 0) return currentCues;

    const firstIndex = batchCues[0].cue_index;
    const contextBefore = currentCues
      .filter((c) => c.cue_index < firstIndex)
      .slice(-4)
      .map((c) => ({
        index: c.cue_index,
        source: c.source_text,
        translated: c.translated_text,
      }));

    setActiveBatch(batchNum);

    const res = await fetch("/api/translate-batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        provider: cfg.provider,
        apiKey: cfg.apiKey,
        baseUrl: cfg.baseUrl,
        model: cfg.model,
        safetyOff: cfg.safetyOff,
        sourceLang: project.source_lang,
        targetLang: project.target_lang,
        tone: glossary?.tone ?? "natural_colloquial",
        toneNotes: glossary?.tone_notes ?? null,
        synopsis: glossary?.synopsis ?? null,
        glossaryEntries: glossary?.entries ?? [],
        contextBefore,
        cues: batchCues.map((c) => ({ index: c.cue_index, text: c.source_text })),
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      const errText = data?.error || `HTTP ${res.status}`;
      // Mark batch cues as failed in Supabase & state
      await supabase
        .from("subtitle_cues")
        .update({ status: "failed", error_message: errText })
        .eq("project_id", project.id)
        .eq("batch_number", batchNum);

      return currentCues.map((c) =>
        c.batch_number === batchNum
          ? { ...c, status: "failed", error_message: errText }
          : c
      );
    }

    const mapByIndex = new Map<number, string>();
    for (const item of data.translations as Array<{
      index: number;
      translated: string;
    }>) {
      mapByIndex.set(item.index, item.translated);
    }

    // Update Supabase cue by cue in parallel for this batch
    await Promise.all(
      batchCues.map((c) =>
        supabase
          .from("subtitle_cues")
          .update({
            translated_text: mapByIndex.get(c.cue_index) ?? c.translated_text,
            status: "translated",
            error_message: null,
          })
          .eq("id", c.id)
      )
    );

    return currentCues.map((c) =>
      c.batch_number === batchNum
        ? {
            ...c,
            translated_text: mapByIndex.get(c.cue_index) ?? c.translated_text,
            status: "translated",
            error_message: null,
          }
        : c
    );
  }

  async function runBatchLoop(targetBatches?: number[]) {
    if (!project || translating) return;
    stopRef.current = false;
    setTranslating(true);
    setStatusMsg(null);

    let workingCues = [...cues];
    const batchesToRun =
      targetBatches ??
      Array.from(
        new Set(
          workingCues
            .filter((c) => c.status === "pending" || c.status === "failed")
            .map((c) => c.batch_number)
        )
      ).sort((a, b) => a - b);

    try {
      await supabase
        .from("translation_projects")
        .update({ status: "translating" })
        .eq("id", project.id);

      for (const bNum of batchesToRun) {
        if (stopRef.current) break;
        workingCues = await translateSingleBatch(bNum, workingCues);
        setCues(workingCues);

        const doneCount = workingCues.filter(
          (c) => c.status === "translated" || c.status === "edited"
        ).length;
        const hasFail = workingCues.some((c) => c.status === "failed");

        await supabase
          .from("translation_projects")
          .update({
            translated_cues: doneCount,
            status: hasFail
              ? "has_errors"
              : doneCount === workingCues.length
                ? "completed"
                : "paused",
          })
          .eq("id", project.id);
      }
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : "เกิดข้อผิดพลาดระหว่างแปล");
    } finally {
      setActiveBatch(null);
      setTranslating(false);
    }
  }

  function handleEditCue(cue: SubtitleCue, newText: string) {
    setCues((prev) =>
      prev.map((c) =>
        c.id === cue.id
          ? { ...c, translated_text: newText, status: "edited" }
          : c
      )
    );

    if (saveTimersRef.current[cue.id]) {
      clearTimeout(saveTimersRef.current[cue.id]);
    }
    saveTimersRef.current[cue.id] = setTimeout(async () => {
      await supabase
        .from("subtitle_cues")
        .update({ translated_text: newText, status: "edited" })
        .eq("id", cue.id);
    }, 600);
  }

  function handleExportSrt() {
    if (!project) return;
    const content = serializeSrt(cues);
    const filename = buildExportFilename(
      project.original_filename,
      project.target_lang
    );
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0d0f14] text-slate-400">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-[#0d0f14]">
        <NavBar />
        <div className="p-8 text-center text-sm text-slate-400">
          ไม่พบโปรเจกต์นี้
        </div>
      </div>
    );
  }

  const pct = stats.total > 0 ? Math.round((stats.done / stats.total) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#0d0f14] pb-12">
      <NavBar />

      {/* Sticky Toolbar */}
      <div className="sticky top-[57px] z-20 border-b border-white/10 bg-[#151922]/95 px-4 py-3 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="line-clamp-1 text-sm font-bold text-white sm:text-base">
              {project.title}
            </h1>
            <p className="text-xs text-slate-400">
              {stats.done}/{stats.total} บรรทัด ({pct}%)
              {activeBatch ? ` • กำลังแปล Batch #${activeBatch}...` : ""}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {!translating ? (
              <button
                onClick={() => runBatchLoop()}
                className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-500"
              >
                <Play className="h-3.5 w-3.5" />
                {stats.done > 0 ? "แปลต่อที่เหลือ" : "เริ่มแปลทั้งไฟล์"}
              </button>
            ) : (
              <button
                onClick={() => {
                  stopRef.current = true;
                }}
                className="flex items-center gap-1.5 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-amber-500"
              >
                <Pause className="h-3.5 w-3.5" /> หยุดชั่วคราว
              </button>
            )}

            <button
              onClick={handleExportSrt}
              className="flex items-center gap-1.5 rounded-xl border border-white/15 bg-[#0d0f14] px-3.5 py-2 text-xs font-semibold text-white hover:border-indigo-400"
            >
              <Download className="h-3.5 w-3.5" /> Export .srt
            </button>
          </div>
        </div>

        {/* Filter tabs */}
        <div className="mx-auto mt-3 flex max-w-6xl items-center gap-1.5 overflow-x-auto">
          {(
            [
              ["all", `ทั้งหมด (${stats.total})`],
              ["pending", `ยังไม่แปล (${stats.total - stats.done - stats.failed})`],
              ["failed", `มีปัญหา (${stats.failed})`],
              ["done", `แปลแล้ว (${stats.done})`],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={`shrink-0 rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                filter === key
                  ? "bg-indigo-500/25 text-indigo-300"
                  : "text-slate-400 hover:bg-white/5"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-6xl space-y-4 px-4 pt-4">
        {statusMsg && (
          <div className="flex items-center justify-between rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
            <span>{statusMsg}</span>
            <Link
              href="/settings"
              className="ml-2 flex shrink-0 items-center gap-1 underline"
            >
              <Settings className="h-3.5 w-3.5" /> ตั้งค่า API
            </Link>
          </div>
        )}

        {stats.failedBatchNums.length > 0 && !translating && (
          <div className="flex flex-col gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3.5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-2 text-xs text-amber-200">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
              <div>
                พบ Batch ที่แปลไม่สำเร็จ (#{stats.failedBatchNums.join(", #")})
                — คุณสามารถไปหน้า{" "}
                <Link href="/settings" className="underline">
                  ตั้งค่า API
                </Link>{" "}
                เพื่อสลับโมเดล แล้วกดแปลซ่อมเฉพาะท่อนนี้ได้ทันที
              </div>
            </div>
            <button
              onClick={() => runBatchLoop(stats.failedBatchNums)}
              className="flex shrink-0 items-center justify-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-black hover:bg-amber-400"
            >
              <RefreshCw className="h-3.5 w-3.5" /> แปลซ้ำเฉพาะท่อนที่พลาด
            </button>
          </div>
        )}

        {/* Responsive Cue List: Stacked Card on Mobile, Side-by-Side on Desktop */}
        <div className="space-y-3">
          {filteredCues.map((cue) => (
            <div
              key={cue.id}
              className={`surface-card rounded-xl p-3.5 sm:p-4 ${
                cue.status === "failed" ? "border-rose-500/40" : ""
              }`}
            >
              <div className="mb-2 flex items-center justify-between text-[11px] text-slate-400">
                <span className="font-mono">
                  #{cue.cue_index} • {cue.start_time} → {cue.end_time}
                </span>
                <span
                  className={`rounded px-1.5 py-0.5 font-medium ${
                    cue.status === "translated" || cue.status === "edited"
                      ? "bg-emerald-500/15 text-emerald-300"
                      : cue.status === "failed"
                        ? "bg-rose-500/15 text-rose-300"
                        : "bg-white/10 text-slate-400"
                  }`}
                >
                  Batch {cue.batch_number} • {cue.status}
                </span>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-lg bg-[#0d0f14] p-3 text-sm whitespace-pre-wrap text-slate-200">
                  {cue.source_text}
                </div>
                <div>
                  <textarea
                    rows={Math.max(2, cue.source_text.split("\n").length)}
                    value={cue.translated_text ?? ""}
                    onChange={(e) => handleEditCue(cue, e.target.value)}
                    placeholder="คำแปลภาษาไทย..."
                    className="w-full rounded-lg border border-white/10 bg-[#0d0f14] p-3 text-sm text-white placeholder-slate-600 focus:border-indigo-500 focus:outline-none"
                  />
                  {cue.error_message && (
                    <p className="mt-1 text-[11px] text-rose-400">
                      {cue.error_message}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
