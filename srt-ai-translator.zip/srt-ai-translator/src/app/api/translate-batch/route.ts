import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { callGemini } from "@/lib/llm/gemini";
import { callOpenAiCompatible } from "@/lib/llm/openai-compatible";
import { parseAndValidateTranslation } from "@/lib/llm/prompt";
import type { TranslateBatchPayload } from "@/lib/llm/types";

export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const payload = (await req.json()) as TranslateBatchPayload;

    if (!payload.apiKey?.trim()) {
      return NextResponse.json(
        { error: "API key is required. Configure it in Settings." },
        { status: 400 }
      );
    }

    if (!Array.isArray(payload.cues) || payload.cues.length === 0) {
      return NextResponse.json(
        { error: "No cues provided in batch." },
        { status: 400 }
      );
    }

    const invokeLlm = () =>
      payload.provider === "gemini"
        ? callGemini(payload)
        : callOpenAiCompatible(payload);

    let lastError: unknown;
    // Try up to 2 times (initial + 1 auto-retry for transient parse/index mismatches)
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const raw = await invokeLlm();
        const translations = parseAndValidateTranslation(raw, payload.cues);
        return NextResponse.json({ translations });
      } catch (err) {
        lastError = err;
        const msg = err instanceof Error ? err.message : String(err);
        // Do not retry hard safety refusals with the exact same settings
        if (msg.startsWith("REFUSAL:")) {
          return NextResponse.json(
            { error: msg, code: "REFUSAL" },
            { status: 422 }
          );
        }
      }
    }

    const message =
      lastError instanceof Error ? lastError.message : "Translation batch failed";

    return NextResponse.json(
      { error: message, code: "BATCH_FAILED" },
      { status: 422 }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
