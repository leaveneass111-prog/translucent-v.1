"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  FileText,
  Loader2,
  Trash2,
  UploadCloud,
  ArrowRight,
} from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { createClient } from "@/lib/supabase/client";
import { parseSrt } from "@/lib/srt/parser";
import { loadLocalApiConfig } from "@/lib/settings-storage";
import type { Glossary, TranslationProject } from "@/types/database";

export default function DashboardPage() {
  const router = useRouter();
  const supabase = createClient();

  const [projects, setProjects] = useState<TranslationProject[]>([]);
  const [glossaries, setGlossaries] = useState<Glossary[]>([]);
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("th");
  const [glossaryId, setGlossaryId] = useState<string>("");
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadData() {
    const [{ data: projData }, { data: glossData }] = await Promise.all([
      supabase
        .from("translation_projects")
        .select("*")
        .order("updated_at", { ascending: false }),
      supabase.from("glossaries").select("*").order("name", { ascending: true }),
    ]);
    if (projData) setProjects(projData as TranslationProject[]);
    if (glossData) setGlossaries(glossData as Glossary[]);
  }

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleFile(file: File) {
    setError(null);
    if (!file.name.toLowerCase().endsWith(".srt")) {
      setError("กรุณาเลือกไฟล์นามสกุล .srt เท่านั้น");
      return;
    }

    setUploading(true);
    try {
      const rawText = await file.text();
      const parsed = parseSrt(rawText);
      if (parsed.length === 0) {
        throw new Error("ไม่พบข้อความซับไตเติลที่ถูกต้องในไฟล์นี้");
      }

      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error("กรุณาเข้าสู่ระบบใหม่");

      const localCfg = loadLocalApiConfig();
      const batchSize = localCfg.batchSize || 40;

      const { data: project, error: projErr } = await supabase
        .from("translation_projects")
        .insert({
          user_id: user.id,
          glossary_id: glossaryId || null,
          title: file.name.replace(/\.srt$/i, ""),
          original_filename: file.name,
          source_lang: sourceLang,
          target_lang: targetLang,
          batch_size: batchSize,
          total_cues: parsed.length,
          translated_cues: 0,
          status: "draft",
        })
        .select()
        .single();

      if (projErr || !project) throw projErr ?? new Error("สร้างโปรเจกต์ไม่สำเร็จ");

      // Insert cues in chunks of 500 to stay well within payload limits
      const cueRows = parsed.map((cue, idx) => ({
        project_id: project.id,
        user_id: user.id,
        cue_index: cue.cue_index,
        start_time: cue.start_time,
        end_time: cue.end_time,
        source_text: cue.source_text,
        translated_text: null,
        batch_number: Math.floor(idx / batchSize) + 1,
        status: "pending",
      }));

      for (let i = 0; i < cueRows.length; i += 500) {
        const chunk = cueRows.slice(i, i + 500);
        const { error: cueErr } = await supabase
          .from("subtitle_cues")
          .insert(chunk);
        if (cueErr) throw cueErr;
      }

      router.push(`/projects/${project.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "อัปโหลดไฟล์ไม่สำเร็จ");
    } finally {
      setUploading(false);
    }
  }

  async function handleDeleteProject(id: string) {
    await supabase.from("translation_projects").delete().eq("id", id);
    await loadData();
  }

  return (
    <div className="min-h-screen bg-[#0d0f14]">
      <NavBar />
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-6">
        <section className="surface-card rounded-2xl p-5 sm:p-6">
          <h1 className="mb-4 text-base font-bold text-white sm:text-lg">
            สร้างงานแปล .srt ใหม่
          </h1>

          <div className="mb-4 grid gap-3 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs text-slate-400">ภาษาต้นทาง</label>
              <select
                value={sourceLang}
                onChange={(e) => setSourceLang(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white"
              >
                <option value="en">อังกฤษ (English)</option>
                <option value="ja">ญี่ปุ่น (Japanese)</option>
                <option value="zh">จีน (Chinese)</option>
                <option value="ko">เกาหลี (Korean)</option>
                <option value="auto">ตรวจจับอัตโนมัติ (Auto)</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs text-slate-400">ภาษาเป้าหมาย</label>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white"
              >
                <option value="th">ไทย (Thai)</option>
                <option value="en">อังกฤษ (English)</option>
                <option value="ja">ญี่ปุ่น (Japanese)</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs text-slate-400">ชุด Glossary (ไม่บังคับ)</label>
              <select
                value={glossaryId}
                onChange={(e) => setGlossaryId(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-[#0d0f14] px-3 py-2 text-sm text-white"
              >
                <option value="">ไม่ใช้ Glossary</option>
                {glossaries.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <label
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleFile(file);
            }}
            className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-4 py-10 text-center transition ${
              dragging
                ? "border-indigo-400 bg-indigo-500/10"
                : "border-white/15 bg-[#0d0f14] hover:border-indigo-500/50"
            }`}
          >
            {uploading ? (
              <Loader2 className="mb-2 h-8 w-8 animate-spin text-indigo-400" />
            ) : (
              <UploadCloud className="mb-2 h-8 w-8 text-indigo-400" />
            )}
            <p className="text-sm font-medium text-white">
              {uploading ? "กำลังอ่านและบันทึกไฟล์ .srt..." : "แตะเพื่อเลือก หรือลากไฟล์ .srt มาวางที่นี่"}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              รองรับไฟล์ขนาดยาวและซับหลายบรรทัด Timecode จะถูกล็อกอัตโนมัติ
            </p>
            <input
              type="file"
              accept=".srt"
              disabled={uploading}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFile(file);
              }}
              className="hidden"
            />
          </label>

          {error && (
            <div className="mt-3 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">
              {error}
            </div>
          )}
        </section>

        <section className="surface-card rounded-2xl p-5 sm:p-6">
          <h2 className="mb-4 text-base font-bold text-white">งานแปลล่าสุด</h2>
          {projects.length === 0 ? (
            <p className="py-8 text-center text-xs text-slate-500">
              ยังไม่มีงานแปล เริ่มจากอัปโหลดไฟล์ .srt ด้านบนได้เลย
            </p>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {projects.map((p) => {
                const pct =
                  p.total_cues > 0
                    ? Math.round((p.translated_cues / p.total_cues) * 100)
                    : 0;
                return (
                  <div
                    key={p.id}
                    className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#0d0f14] p-4"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 shrink-0 text-indigo-400" />
                          <h3 className="line-clamp-1 text-sm font-semibold text-white">
                            {p.title}
                          </h3>
                        </div>
                        <button
                          onClick={() => handleDeleteProject(p.id)}
                          className="rounded-lg p-1 text-slate-500 hover:bg-rose-500/10 hover:text-rose-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="mt-1 text-xs text-slate-400">
                        {p.source_lang.toUpperCase()} → {p.target_lang.toUpperCase()} •{" "}
                        {p.translated_cues}/{p.total_cues} บรรทัด ({pct}%)
                      </p>
                      <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                        <div
                          className="h-full bg-indigo-500 transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between">
                      <span
                        className={`rounded-md px-2 py-0.5 text-[11px] font-medium ${
                          p.status === "completed"
                            ? "bg-emerald-500/15 text-emerald-300"
                            : p.status === "has_errors"
                              ? "bg-rose-500/15 text-rose-300"
                              : "bg-slate-500/20 text-slate-300"
                        }`}
                      >
                        {p.status}
                      </span>
                      <Link
                        href={`/projects/${p.id}`}
                        className="flex items-center gap-1 text-xs font-medium text-indigo-400 hover:text-indigo-300"
                      >
                        เปิด Editor <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
