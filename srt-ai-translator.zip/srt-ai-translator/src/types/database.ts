export type CueStatus = "pending" | "translated" | "failed" | "edited";
export type ProjectStatus =
  | "draft"
  | "translating"
  | "paused"
  | "completed"
  | "has_errors";
export type TonePreset =
  | "natural_colloquial"
  | "polite"
  | "explicit_raw"
  | "custom";
export type LlmProvider = "gemini" | "openrouter" | "custom";

export interface GlossaryEntry {
  source: string;
  target: string;
  pronoun?: string;
  notes?: string;
}

export interface Glossary {
  id: string;
  user_id: string;
  name: string;
  tone: TonePreset;
  tone_notes: string | null;
  synopsis: string | null;
  entries: GlossaryEntry[];
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  user_id: string;
  default_provider: LlmProvider;
  custom_base_url: string | null;
  default_model: string;
  default_source_lang: string;
  default_target_lang: string;
  default_batch_size: number;
  gemini_safety_off: boolean;
  updated_at: string;
}

export interface TranslationProject {
  id: string;
  user_id: string;
  glossary_id: string | null;
  title: string;
  original_filename: string;
  source_lang: string;
  target_lang: string;
  batch_size: number;
  total_cues: number;
  translated_cues: number;
  failed_batches: number[];
  status: ProjectStatus;
  created_at: string;
  updated_at: string;
}

export interface SubtitleCue {
  id: string;
  project_id: string;
  user_id: string;
  cue_index: number;
  start_time: string;
  end_time: string;
  source_text: string;
  translated_text: string | null;
  batch_number: number;
  status: CueStatus;
  error_message: string | null;
  updated_at: string;
}

export interface LocalApiConfig {
  provider: LlmProvider;
  apiKey: string;
  baseUrl: string;
  model: string;
  safetyOff: boolean;
  batchSize: number;
}
