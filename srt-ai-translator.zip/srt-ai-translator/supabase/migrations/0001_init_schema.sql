-- Enable UUID extension
create extension if not exists "pgcrypto";

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  default_provider text not null default 'openrouter',
  custom_base_url text,
  default_model text not null default 'google/gemini-2.5-flash',
  default_source_lang text not null default 'auto',
  default_target_lang text not null default 'th',
  default_batch_size integer not null default 40 check (default_batch_size between 10 and 100),
  gemini_safety_off boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.glossaries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  tone text not null default 'natural_colloquial',
  tone_notes text,
  synopsis text,
  entries jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.translation_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  glossary_id uuid references public.glossaries(id) on delete set null,
  title text not null,
  original_filename text not null,
  source_lang text not null default 'en',
  target_lang text not null default 'th',
  batch_size integer not null default 40,
  total_cues integer not null default 0,
  translated_cues integer not null default 0,
  failed_batches jsonb not null default '[]'::jsonb,
  status text not null default 'draft' check (status in ('draft', 'translating', 'paused', 'completed', 'has_errors')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.subtitle_cues (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.translation_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  cue_index integer not null,
  start_time text not null,
  end_time text not null,
  source_text text not null,
  translated_text text,
  batch_number integer not null,
  status text not null default 'pending' check (status in ('pending', 'translated', 'failed', 'edited')),
  error_message text,
  updated_at timestamptz not null default now(),
  unique (project_id, cue_index)
);

create index if not exists idx_projects_user_updated on public.translation_projects(user_id, updated_at desc);
create index if not exists idx_cues_project_index on public.subtitle_cues(project_id, cue_index asc);
create index if not exists idx_cues_project_status on public.subtitle_cues(project_id, status);
create index if not exists idx_cues_project_batch on public.subtitle_cues(project_id, batch_number);

create or replace function public.handle_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_user_settings_updated on public.user_settings;
create trigger trg_user_settings_updated before update on public.user_settings
  for each row execute function public.handle_updated_at();

drop trigger if exists trg_glossaries_updated on public.glossaries;
create trigger trg_glossaries_updated before update on public.glossaries
  for each row execute function public.handle_updated_at();

drop trigger if exists trg_projects_updated on public.translation_projects;
create trigger trg_projects_updated before update on public.translation_projects
  for each row execute function public.handle_updated_at();

drop trigger if exists trg_cues_updated on public.subtitle_cues;
create trigger trg_cues_updated before update on public.subtitle_cues
  for each row execute function public.handle_updated_at();

alter table public.user_settings enable row level security;
alter table public.glossaries enable row level security;
alter table public.translation_projects enable row level security;
alter table public.subtitle_cues enable row level security;

create policy "Users manage own settings" on public.user_settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Users manage own glossaries" on public.glossaries
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Users manage own projects" on public.translation_projects
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Users manage own cues" on public.subtitle_cues
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
