# SRT AI Translator

เว็บแอปแปลไฟล์ซับไตเติล `.srt` แบบ Mobile-first (Next.js + Supabase + Vercel) รองรับเนื้อหาสำหรับผู้ใหญ่ผ่านการสลับโมเดลและ Custom Endpoint (OpenRouter, Gemini, Grok, DeepSeek)

## การติดตั้งและ Deploy

1. **ติดตั้ง Dependencies**
   ```bash
   npm install
   ```

2. **ตั้งค่า Environment Variables**
   สร้างไฟล์ `.env.local` (สำหรับรันบนเครื่อง) และใส่ใน **Vercel → Settings → Environment Variables**:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://rrgnzlbipoozzajrwqte.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_your_publishable_key
   ```

3. **รันบนเครื่อง**
   ```bash
   npm run dev
   ```

4. **หลัง Deploy ขึ้น Vercel**
   นำโดเมนที่ได้ (เช่น `https://your-app.vercel.app/**`) ไปเพิ่มใน **Supabase → Authentication → URL Configuration → Redirect URLs**
